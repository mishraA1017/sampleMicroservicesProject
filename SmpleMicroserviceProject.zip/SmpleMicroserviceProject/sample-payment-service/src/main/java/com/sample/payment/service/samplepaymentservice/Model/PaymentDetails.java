package com.sample.payment.service.samplepaymentservice.Model;

public class PaymentDetails {

	
	OrderDetails paymentDetails = new OrderDetails();

	public OrderDetails getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(OrderDetails paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	
	
	
}
