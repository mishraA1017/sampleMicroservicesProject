package com.sample.payment.service.samplepaymentservice.services;

import com.sample.payment.service.samplepaymentservice.Model.OrderDetails;

public interface OrderServiceInf {

	public OrderDetails saveOrderDetails(OrderDetails orderDetails); 
		
}
