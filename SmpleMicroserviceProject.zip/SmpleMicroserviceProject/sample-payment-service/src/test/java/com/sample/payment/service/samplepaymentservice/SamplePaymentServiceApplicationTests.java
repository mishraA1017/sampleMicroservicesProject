package com.sample.payment.service.samplepaymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamplePaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
