package com.sample.order.placeorderservice.placeorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaceOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
