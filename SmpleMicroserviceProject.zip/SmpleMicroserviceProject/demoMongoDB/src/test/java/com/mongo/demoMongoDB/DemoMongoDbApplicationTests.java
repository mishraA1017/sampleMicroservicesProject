package com.mongo.demoMongoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
