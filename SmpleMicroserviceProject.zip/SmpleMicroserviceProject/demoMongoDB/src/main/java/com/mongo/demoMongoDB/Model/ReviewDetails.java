package com.mongo.demoMongoDB.Model;

public class ReviewDetails {

	private String userId;
	private String review;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
	
}
