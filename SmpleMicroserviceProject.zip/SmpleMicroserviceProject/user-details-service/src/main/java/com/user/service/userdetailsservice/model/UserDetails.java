package com.user.service.userdetailsservice.model;

public class UserDetails {

	UserProfile userDetails= new UserProfile();

	public UserProfile getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserProfile userDetails) {
		this.userDetails = userDetails;
	}
	
	
	
	
}
